<?php
require __DIR__ . '/vendor/autoload.php';

use \App\Pix\Payload;

// Instância principal do Payload Pix
$obPayload = (new Payload())
    ->setPixKey('11786862565') // Chave Pix
    ->setDescription('Pagamento do Pedido 123') // Descrição
    ->setMerchantName('Joao Lucas Rezende Souza') // Nome do Recebedor
    ->setMerchantCity('Salvador') // Cidade do Recebedor
    ->setAmount('10.00') // Valor da Transação
    ->setTxid('JL1234'); // ID da Transação

// Código de pagamento Pix
$payloadQrCode = $obPayload->getPayload();

// Exibe o payload gerado
echo "<pre>";
print_r($payloadQrCode);
echo "</pre>";
exit;
