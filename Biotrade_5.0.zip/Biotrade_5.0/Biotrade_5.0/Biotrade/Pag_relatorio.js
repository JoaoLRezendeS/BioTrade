// Botão para emitir relatório
document.getElementById('emitButton').addEventListener('click', () => {
    alert('Relatório emitido com sucesso!');
  });
  
  // Botão para fechar
  document.getElementById('closeButton').addEventListener('click', () => {
    alert('Janela fechada.');
  });
  
  